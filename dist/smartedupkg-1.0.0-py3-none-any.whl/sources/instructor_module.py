
from abc import ABC, abstractmethod
from utils import get_next_student_number, get_next_instructor_number, clear_UI

def decorate_new_instructor(func):
    """This decorator is called while while a new instructor in the system. 
    It get next available instructor number and assigns to the newly created instructor.
    Finally executes existing add_new_instructor_to_file method in Instructor class.
    """
    def wrapper(*args):
        self = args[0]
        self.instructor_number = get_next_instructor_number()
        return func(*args)
    return wrapper


class Person(ABC):
    def __init__(self,name,email,mobile):
        self.name = name
        self.email = email
        self.mobile = mobile

class Instructor(Person):
    def __init__(self,name,email,mobile,instructor_number=0):
        super().__init__(name,email,mobile)
        self.rating = 0
        self.instructor_name = instructor_number
        if instructor_number == 0:
            #self.instructor_number = get_next_instructor_number()
            pass
        else:
            self.instructor_number = instructor_number
      
    def __str__(self):
        return f'{self.instructor_number} ### {self.name} ### {self.email} ### {self.mobile} ### {self.rating}'

    def new_instructor_decorator(self, func):
        def wrapper(*agrs):
            self.instructor_number = get_next_instructor_number()
            print(f' instructor nbr {self.instructor_number}, name {self.name}, email {emai}')
            return self.func
        return wrapper

    @decorate_new_instructor
    def add_new_instructor_to_file(self):
        with open('InstructorMaster.txt','a') as instructor_file:
            instructor_file.write(str(self) + '\n')
                

def find_instructor(par_instructor):
    instructor_found = False
    instructor_number = str()
    name = str()
    email = str()
    mobile = str()
    rating = str()

    with open('InstructorMaster.txt','r') as instructor_file:
        for each_instructor in instructor_file:
            if each_instructor.count('###') > 1:
                rcd_instructor_number,rcd_name,rcd_email,rcd_mobile,rcd_rating = each_instructor.strip().split('###')
                if rcd_instructor_number.strip() == par_instructor.strip():
                    name = rcd_name.strip()
                    email = rcd_email.strip()
                    mobile = rcd_mobile.strip()
                    rating = rcd_rating.strip()
                    instructor_found= True
                    break
    return instructor_found, name, email, mobile, rating


def add_new_instructor():
    while True:
        print('\n\n\t\t*********** Add new Instructor **********\n')
        name  = input('\t\tInstructor name : ')
        email = input('\n\t\tEmail id . . : ')
        mobile= input('\n\t\tMobile . . . : ')

        new_instructor=Instructor(name,email,mobile)
        new_instructor.add_new_instructor_to_file()
        clear_UI()
    
        print(f'\n\n\t\t *** Created new Instructor with following details *** ')
        print(f'\n\t\t Instructor Number  : {new_instructor.instructor_number}')
        print(f'\n\t\t Name   . . . . . . : {new_instructor.name}')
        print(f'\n\t\t Email ID . . . . . : {new_instructor.email}')
        print(f'\n\t\t Mobile . . . . . . : {new_instructor.mobile}')

        new_enroll = input('\n\t\t Do you want to add another Intructor (Y/N). . ')
        clear_UI()
        if new_enroll.upper() != 'Y':
            break

def find_student_update_grade(student_number,course,new_grade):
    from student_module import Student, find_student

    __student_found,name,email,mobile,courses = find_student(student_number)

    if __student_found == True:
        student1 = Student(name,email,mobile, courses,student_number)
        student1.update_grade(course,new_grade)
    else:
        print(f'\n\t\tStudent number {student_number} not found in the system.')


def update_student_grade():
    while True:
        print('\n\n\t\t*********** Update Student Grade **********\n')
        student_number  = input('\t\tEnter Student Number . : ')
        course = input('\n\t\tCourse ID  . . . . : ')
        new_grade = input('\n\t\tGrade  . . . . . . : ')
        clear_UI()

        find_student_update_grade(student_number,course,new_grade)

        new_enroll = input('\n\t\t Do you want to update grade for another student (Y/N). . ')
        clear_UI()
        if new_enroll.upper() != 'Y':
            break
    
def display_instructor_details():
    print('\n\n\t\t*********** Display Instructor details **********\n')
    instructor_number = input('\n\t\tInstructor Number . . . .  ')

    __instructor_found,name,email,mobile,rating = find_instructor(instructor_number)

    if __instructor_found == True:
        print(f'\n\t\tName . . . . : {name.strip()}')
        print(f'\n\t\tEmail  . . . : {email.strip()}')
        print(f'\n\t\tMobile . . . : {mobile.strip()}')
        print(f'\n\t\tUser Rating  : {rating.strip()}')
    else:
        print(f'Instructor {instructor_number} not foundin the system')

    a=input('\t\t')
    clear_UI()

def instructor_menu():
    while True:
        print('\n\n\t\t*********** Smart Education Instructor Menu **********\n')
        print('\t\t1. Update Grade for a student \n')
        print('\t\t9. Exit Instructor Menu\n')
       
        user_selection = input('\t\tEnter your option . . . . : ')
        clear_UI()
        match user_selection:
            case '1':
                update_student_grade()
            case '9':
                break
            case _:
                print(f'\n\t\tInvalid option {user_selection} entered.')