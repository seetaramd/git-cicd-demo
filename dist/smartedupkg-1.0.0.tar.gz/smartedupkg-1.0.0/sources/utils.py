
def get_next_student_number():
    '''This function increments most recently created Student Number1 and retustudent_nns thstudent N                print(f'{next_number_list[0
    print(f'{updated_list}'].strip()} and {next_number_list[1].strip()}')umber.''' 

    next_student_number = 1
    updated_line = f'{1} ### {0}'

    try:
        with open('application_next_values.txt','r') as file1:
            for line in file1:
                next_number_list = line.strip().split('###')
                next_student_number = str(int(next_number_list[0].strip())+1)
                updated_line = f'{next_student_number.strip()} ### {next_number_list[1].strip()}'
                break
    except:
        print('error while opening Application Next Values file.')
    
    with open('application_next_values.txt','w') as file1:
        file1.write(updated_line)
    return next_student_number


def get_next_instructor_number():
    """This function increments most recently created instrucutor Number by 1 and returns the value as next Instrucutor Number.""" 

    next_instructor_number = 1
    updated_line = f'{0} ### {1}'

    try:
        with open('application_next_values.txt','r') as file1:
            for line in file1:
                next_number_list = line.strip().split('###')
                next_instructor_number = str(int(next_number_list[1].strip())+1) 
                updated_line = f'{next_number_list[0].strip()} ### {next_instructor_number.strip()}'
                break
    except:
        pass

    with open('application_next_values.txt','w') as file1:
        file1.write(updated_line)
    
    return next_instructor_number


def clear_UI():
    import os
    if os.name == 'nt':
        os.system('cls')


class MyCustomError(Exception):
    """ Customized Exception Handling."""
    pass


class CourseError(Exception):
    """ Customized Exception Handling while adding courses and assigning instructor."""
    pass