import student_module
import instructor_module
from admin_module import admin_menu
from utils import clear_UI


clear_UI()

# Continue the main menu loop till user selects option 9 to exit from the application
while True:
    print('\n\n\t\t ********** Smart Education Main Menu **********\n')
    print('\t\t1. Admin Activities\n')
    print('\t\t2. Instructor Activities\n')
    print('\t\t3. Student Activities\n')
    print('\t\t9. Exit Application\n')
    
    user_selection = input('\t\tEnter your option . . . . : ')
    clear_UI()
    match user_selection:
        case '1':
            admin_menu()
        case '2':
            instructor_module.instructor_menu()
        case '3':
            student_module.student_menu()
        case '9':
            break
        case _:
            print(f'\n\t\tInvalid option {user_selection} entered.')