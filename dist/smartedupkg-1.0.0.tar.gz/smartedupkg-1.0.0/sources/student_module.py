
from abc import ABC, abstractmethod
import course_module
from utils import get_next_student_number, clear_UI, MyCustomError

def decorate_new_student(func):
    """ Decorator to get next available student number while creating new student in the system."""
    def wrapper(*args):
        self = args[0]
        self.student_number = get_next_student_number()
        return func(*args)
    return wrapper

class Person(ABC):
    def __init__(self,name,email,mobile):
        self.name = name
        self.email = email
        self.mobile = mobile

class Student(Person):
    def __init__(self,name,email,mobile, courses=' ',student_number=0):
        super().__init__(name,email,mobile)
        self.courses = courses
        self.student_number = student_number
      
    def __str__(self):
        return f'{self.student_number} ### {self.name} ### {self.email} ### {self.mobile} ### {self.courses}'

    @decorate_new_student
    def add_new_student(self):
        with open('StudentMaster.txt','a') as student_file:
            student_file.write(str(self) + '\n')
            
    def update_to_file(self):
        with open('StudentMaster.txt','r') as student_file:
            students = list()
            for each_student in student_file:
                if each_student.count('###') > 1:
                    std_number,std_name,std_email,std_mobile, std_courses = each_student.strip().split('###')
                    if std_number.strip() == self.student_number.strip():
                           students.append(str(self) +'\n')
                    else:
                        students.append(each_student + '\n')
                        
                elif len(each_student.strip()) > 0 :
                    students.append(each_student + '\n')

        with open('StudentMaster.txt','w') as student_file:
            student_file.writelines(students)
        

    def set_course_grade(self,course,new_grade):
        updated_courses = str()
        student_courses = self.courses.split('***')
        for each_course in student_courses:
            course_detail = each_course.split(',')
            if len(course_detail) > 0:
                if course_detail[0].strip()== course.strip() :
                    course_detail[1] = new_grade
            each_course = ",".join(course_detail)        
            if updated_courses.strip() == '':
                updated_courses = f'{each_course}'
            else:
                updated_courses = f'{updated_courses} *** {each_course}'
        
        self.courses = updated_courses
        print(f'student sources : {self.courses}')

    def update_grade(self,course,new_grade):
        
        self.set_course_grade(course,new_grade)
          
        with open('StudentMaster.txt','r') as student_file:
            students = list()
            for each_student in student_file:
                if each_student.count('###') > 1:
                    std_number,std_name,std_email,std_mobile, std_courses = each_student.strip().split('###')
                    if std_number.strip() == self.student_number.strip():
                           students.append(str(self) +'\n')
                    else:
                        students.append(each_student + '\n')
                        
                elif len(each_student.strip()) > 0 :
                    students.append(each_student + '\n')

        with open('StudentMaster.txt','w') as student_file:
            student_file.writelines(students)     

            
    def enroll_course(self,new_course,status):
        new_course_details = str()
        if self.courses.strip() == '':
            new_course_details = f' {new_course}, ,{status} '
        else:
            #count = 0
            course_found = False
            updated_courses = []
            course_details = self.courses.split('***')
            for index, x in enumerate(course_details):
                if x.strip != '':
                    if x.split(',')[0].strip() == new_course.strip():
                        x_str = f'{new_course}, ,{status} '
                        course_found = True
                    else:
                        x_str = x

                    #if count == 0:
                    if index ==0:
                       updated_courses.append(x_str)
                    else:
                        updated_courses.append(f' *** {x_str} ')
    
                    #count += 1

            for x in updated_courses:
                new_course_details = new_course_details.strip() + x

            if course_found == False:
                if len(course_details) > 0:
                    new_course_details = new_course_details.strip()  + f' *** {new_course}, ,{status}'
                else:
                    new_course_details = f' {new_course}, ,{status}'

        course_found, r_course, r_description, r_instructor, r_total_enrolments = course_module.find_course(new_course)
        if course_found == True:

            #self.courses = self.courses.strip() + new_course_details
            self.courses = new_course_details
            self.update_to_file()
            #update_student_courses
            print(f'\n\t\tThank you for enrolling to couse {new_course}.')
            
            # try to increase total enrolments in couse master. Look for customized error and print them
            try:
                course_module.update_total_enrolments(new_course, "Enroll")
            except MyCustomError as error_description:
                print(f"\n\t\tError found : {error_description}")
            
        else:
            print(f'\n\t\tCourse {new_course} not found in the System.')


    def disenroll_course(self,disenroll_course,status):
        student_courses = self.courses.split('***')
        updated_courses = str()
        for course in student_courses:
            course_detail = course.split(',')
            if len(course_detail) > 0:
                if course_detail[0].strip()== disenroll_course.strip() :
                    course_detail[2] = status
            course = ",".join(course_detail)        
            if updated_courses.strip() == '':
                updated_courses = f'{course}'
            else:
                updated_courses = f'{updated_courses} *** {course}'

        self.courses = updated_courses
        self.update_to_file()
        print(f'\n\t\tYou got dropped from couse {disenroll_course}.')
        
        # try to increase total enrolments in couse master. Look for customized error and print them
        try:
            course_module.update_total_enrolments(disenroll_course,"Disenroll")
        except MyCustomError as error_description:
            print(f"\n\t\tError found : {error_description}")


def find_student(par_student_number):
    __student_found = False
    name = str()
    email = str()
    mobile = str()
    mobile = str()

    with open('StudentMaster.txt','r') as student_file:
        name = str()
        email = str()
        mobile = str()
        courses = str()
        __student_found= False

        for each_student in student_file:
            if each_student.count('###') > 1:
                std_number,std_name,std_email,std_mobile, std_courses = each_student.strip().split('###')
                if std_number.strip() == par_student_number.strip():
                    name = std_name.strip()
                    email = std_email.strip()
                    mobile = std_mobile.strip()
                    courses = std_courses.strip()
                    __student_found= True
                    break
    
    student_file.close()
    return __student_found, name, email, mobile, courses


def update_student_courses(student_number,course,status):

    __student_found, name, email, mobile, courses = find_student(student_number)
    
    if __student_found == True:
        student1 = Student(name,email,mobile, courses,student_number)
        course_details = courses.split('***')
        for x in course_details:
            if x.strip() != '':
                if x.split(',')[0].strip() == course and x.split(',')[-1].strip() == status.strip():
                    if status == 'A':
                        print(f'\n\t\tStudent {student_number} already enrolled to course {course}')
                    elif x.split(',')[0].strip() == course and x.split(',')[-1].strip() == status.strip():
                        print(f'\n\t\tStudent {student_number} not enrolled to course {course}')
                    return   
        if status == 'A':
            student1.enroll_course(course,status)
        elif status == 'X':
            if courses.count(course) > 0 :
                student1.disenroll_course(course,status)
            else:
                print(f'\n\t\tStudent {student_number} not enrolled to course {course}')
                
    else:
        print(f'\n\t\tStudent number {student_number} not found in the system.')
        
    
def signup_new_students():
    while True:
        print('\n\n\t\t*********** Student Signup ***********\n')
        name  = input('\t\tStudent Name : ')
        email = input('\n\t\tEmail id . . : ')
        mobile= input('\n\t\tMobile . . . : ')
        new_student=Student(name,email,mobile)
        new_student.add_new_student()
        clear_UI()
    
        print(f'\n\n\t\t *** Student Sign up Successful *** ')
        print(f'\n\t\t Student Number . . : {new_student.student_number}')
        print(f'\n\t\t Name   . . . . . . : {new_student.name}')
        print(f'\n\t\t Email id . . . . . : {new_student.email}')
        print(f'\n\t\t Mobile . . . . . . : {new_student.mobile}')

        new_enroll = input(f'\n\t\t Please note your student number {new_student.student_number} for further references.')
        clear_UI()
        if new_enroll.upper() != 'Y':
            break
        
    
def enroll_in_course():
    print('\n\n\t\t*********** Enroll in new Course **********\n')
    student_number = input('\t\tStudent Number : ')
    course =         input('\n\t\tCourse . . . . : ')
    status = 'A'
    update_student_courses(student_number,course,status)
    a = input()
    clear_UI()

def disenroll_from_course():
    print('\n\n\t\t*********** Drop-out from a Course **********\n')
    student_number = input('\t\tStudent number : ')
    course =         input('\n\t\tCourse ID  . . : ')
    status = 'X'
    update_student_courses(student_number,course,status)
    a = input()
    clear_UI()

def display_student_details():
    print('\n\n\t\t*********** Display Student details **********\n')
    student_number = input('\t\tStudent number : ')
    __student_found,name,email,mobile,courses = find_student(student_number)
    
    if __student_found == True:
        student1 = Student(name,email,mobile, courses,student_number)
        print(f'\n\t\tName . . . . : {student1.name}')
        print(f'\n\t\tEmail  . . . : {student1.email}')
        print(f'\n\t\tMobile . . . : {student1.mobile}')
        if student1.courses.strip() != '':
            courses = student1.courses.split('***')
            print(f'\n\t\tCourse\t\tGrade\t\tStatus')
            for each_course in courses:
                course_details = each_course.split(',')
                print(f'\t\t{course_details[0].strip()}\t\t{course_details[1].strip()}\t\t{course_details[2].strip()}')
    else:
        print(f'\t\tStudent number {student_number} not found in the system.')

    a=input('\t\t')
    clear_UI()


def student_menu():
    while True:
        print('\n\n\t\t*********** Smart Education Student Menu **********\n')
        print('\t\t1. Sign Up \n')
        print('\t\t2. Enroll in a new Course\n')
        print('\t\t3. Drop-Out from a Course \n')
        print('\t\t4. Display Student Details \n')
        print('\t\t9. Exit Student Menu\n')
        
        user_selection = input('\t\tEnter your option . . . . : ')
        clear_UI()
        match user_selection:
            case '1':
                signup_new_students()
            case '2':
                enroll_in_course()
            case '3':
                disenroll_from_course()
            case '4':
                display_student_details()
            case '9':
                break
            case _:
                print(f'\n\t\tInvalid option {user_selection} entered.')
