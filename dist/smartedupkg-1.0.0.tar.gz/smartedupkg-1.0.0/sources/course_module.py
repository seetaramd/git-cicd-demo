
from instructor_module import find_instructor
from utils import clear_UI, MyCustomError,CourseError

class Course:

    def __init__(self,course,description,instructor=0,total_enrolments=0):
        self.course=course
        self.description = description
        self.instructor = instructor
        if total_enrolments == 0:
            self.total_enrolments = 0
        else:
            self.total_enrolments = total_enrolments
        
    def __str__(self):
        return f'{self.course} ### {self.description} ### {self.instructor} ### {self.total_enrolments}'
        
    def add_to_file(self):
        with open('CourseMaster.txt','a') as course_file:
            course_file.write(str(self) + '\n')

    def update_course_details(self):
        with open('CourseMaster.txt','r') as course_file:
            courses = list()
            for each_course in course_file:
                if each_course.count('###') > 1:
                    rcd_course,rcd_description,rcd_instructor,rcd_total_enrolments = each_course.strip().split('###')
                    if rcd_course.strip() == self.course.strip():
                        courses.append(str(self) +'\n')
                    else:
                        courses.append(each_course + '\n')
                        
                elif len(each_course.strip()) > 0 :
                    courses.append(each_course + '\n')

        with open('CourseMaster.txt','w') as course_file:
            course_file.writelines(courses)     


def find_course(par_course):
    """ It accepts Couse ID as parameter. Read thru total course file. Find the course. 
    Return the course details and course_found flag True. If course not found, return course_found flag False"""
    course_found = False
    course = str()
    description = str()
    instructor = str()
    total_enrolments = str()

    try:
        with open('CourseMaster.txt','r') as course_file:
            for each_course in course_file:
                if each_course.count('###') > 1:
                    rcd_course,rcd_description,rcd_instructor,rcd_total_enrolments = each_course.strip().split('###')
                    if rcd_course.strip() == par_course.strip():
                        course = rcd_course.strip()
                        description = rcd_description.strip()
                        instructor = rcd_instructor.strip()
                        total_enrolments = rcd_total_enrolments.strip()
                        course_found= True
                        break
    #except FileNotFoundError:
    except:
        pass

    return course_found, course, description, instructor, total_enrolments
    

def add_new_course():
    """ This module allows user to enter course and its details. Adds the course to system."""
    while True:
        print('\n\n\t\t*********** Add new Course Menu **********\n')
        course =      input('\n\t\tCourse ID    . . . . . ')
        description = input('\n\t\tDescription  . . . . . ')
        instructor =  input('\n\t\tInstructor Number  . . ')

        try:
            if course.strip() == '' or description.strip() =='':
                raise CourseError('Course and its description is required.')
            
            if instructor.strip() != '':
                instructor_found, name, email, mobile, rating = find_instructor(instructor)
                if instructor_found == False:
                    raise CourseError(f'Instructor {instructor} not found in the system.')

            course_found, r_course, r_description, r_instructor, r_total_enrolments = find_course(course)
            if course_found == True:
                raise CourseError(f"Course {course} already exists in the System.")

            new_course = Course(course,description,instructor)
            new_course.add_to_file()
            print(f'\n\t\tNew course {course} added to application.')
 
        except CourseError as error_description:
            print(f'\n\t\tError found : {error_description}')

        except :
            print(f'\nt\tError occurred while adding course.')

        finally:
            new_enroll = input('\n\t\tWould you like to add another Course . . . . ')
            clear_UI()
            if new_enroll.upper() != 'Y':
                break

def assign_instructor():
    while True:
        print('\n\n\t\t*********** Assign Instructor to a Course **********\n')
        course =      input('\n\t\tCourse ID    . . .  ')
        instructor =  input('\n\t\tInstructor Number  .  ')
        description = str()
    
        course_found, r_course, r_description, r_instructor, r_total_enrolments = find_course(course)
        if course_found == True:
            if instructor.strip() != '':
                instructor_found, name, email, mobile, rating = find_instructor(instructor)
            else:
                instructor_found = False

            if instructor_found == False:
                print(f'\n\t\tInstructor {instructor} not found in the system.')
                
            else:
                course1 = Course(r_course, r_description, instructor, r_total_enrolments)
                course1.update_course_details()
                print(f'\n\t\tCourse "{course}" details got updated.')
        else:
            print(f'\n\t\tCourse {course} not found in the system.')

        
        new_enroll = input('\n\t\tWould you like to assign instructor for another course (Y/N) . . . . ')
        clear_UI()
        if new_enroll.upper() != 'Y':
            break

def update_total_enrolments(course,enrol_disenrol):
    from utils import MyCustomError
    course_found, r_course,r_description,r_instructor, r_total_enrolments = find_course(course)
    if course_found == True:
        if r_total_enrolments.strip().isdigit():
            if enrol_disenrol == 'Enroll':
                total_enrolments = str(int(r_total_enrolments.strip()) + 1)
            else:
                total_enrolments = str(int(r_total_enrolments.strip()) - 1)

            course1 = Course(r_course, r_description,r_instructor,total_enrolments)
            course1.update_course_details()
        else:
            raise MyCustomError("Total Enrolments is not a numeric value.")
    else:
        print(f'Course {course} not found in Course Master.')


def display_course_details():
    print('\n\n\t\t*********** Display Course details **********\n')
    course =      input('\n\t\tCourse ID   . . . . . ')

    course_found, r_course, r_description, r_instructor, r_total_enrolments = find_course(course)
    if course_found == True:
        
        instructor_found, instructor_name, email, mobile, rating = find_instructor(r_instructor)
        
        print(f'\n\t\tDescription . . . . : {r_description.strip()}')
        print(f'\n\t\tInstructor  . . . . : {r_instructor.strip()} {instructor_name.strip()}')
        print(f'\n\t\tTotal Enrolments  . : {r_total_enrolments.strip()}')
        
    else:
        print(f'\n\t\tCourse {course} not found in the system.')

    a=input('\t\t')
    clear_UI()


def display_all_courses():
    with open('CourseMaster.txt','r') as course_file:
        course_list = list()
        for each_course in course_file:
            if each_course.count('###') > 2:
                one_course = each_course.strip().split('###')
                course_list.append(one_course)

    course_list.sort(key=lambda x : int(x[3].strip()), reverse = True)

    print('\n\n\t\t*********** Display Courses by their popularity **********\n')
    print('\n\t\tCourse\t\tDescription\t\tInstructor\t\tActive Enrolments')
    for x in course_list:
        print(f'\n\t\t{x[0].strip()}\t\t{x[1].strip()}\t\t{x[2].strip()}\t\t\t{x[3].strip()}')

    a=input('\t\t')
    clear_UI()
    