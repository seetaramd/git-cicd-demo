
from utils import clear_UI
from student_module import display_student_details
from instructor_module import add_new_instructor, display_instructor_details
from course_module import add_new_course, assign_instructor, display_course_details, display_all_courses

def admin_menu():
    while True:
        print('\n\n\t\t ********** Smart Education Admin Menu **********\n')
        print('\t\t1. Add new Course \n')
        print('\t\t2. Add new Instructor \n')
        print('\t\t3. Assign Instructor to a Course \n')
        print('\t\t4. Display all Courses \n')
        print('\t\t5. Display specific Course Details \n')
        print('\t\t6. Display Instructor Details \n')
        print('\t\t7. Display Student Details \n')
        print('\t\t9. Exit Admin Menu\n')
        
        user_selection = input('\t\tEnter your option . . . . : ')
        clear_UI()
        match user_selection:
            case '1':
                add_new_course()
            case '2':
                add_new_instructor()
            case '3':
                assign_instructor()
            case '4':
                display_all_courses()
            case '5':
                display_course_details()
            case '6':
                display_instructor_details()
            case '7':
                display_student_details()
            case '9':
                break
            case _:
                print(f'\n\t\tInvalid option {user_selection} entered.')
  